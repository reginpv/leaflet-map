# leaflet-map

A demo/sample Leaflet js with multiple markers and panning.

### Installation

- clone static files `git clone https://github.com/reginpv/leaflet-map.git .`